﻿# -*- coding: utf-8 -*-
"""factorial.py

Student: Somil Jain
"""

n = 5
fact = 1
for i in range(1, n + 1):
    fact = fact * i
print(fact)
